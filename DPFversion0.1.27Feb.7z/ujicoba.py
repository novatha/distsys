from bfs_pf2 import *
MVAbase=1
kVAbase=12.47
Zbase=kVAbase**2/MVAbase
# Test Line3
zd=[[0.4013+1.4133*1j, 0.0953+0.8515*1j, 0.0953+0.7266*1j],
    [0.0953+0.8515*1j, 0.4013+1.4133*1j, 0.0953 +0.7802*1j],
    [0.0953+0.7266*1j, 0.0953+0.7802*1j, 0.4013+1.4133*1j]
    ]
#zd=np.eye(3,3)
zd=np.array(zd)/Zbase
Z1=zd*2000/5280
Z2=zd*2500/5280

# Test Case3
busa=pn.Bus()
bus1=RootBus3(busa,busa,busa)
bus2=Bus3(busa,busa,busa)
bus3=Bus3(busa,busa,busa)
bus4=Bus3(busa,busa,busa)
Pa=1.8
pfa=0.9
Pb=1.8
pfb=0.9
Pc=1.8
pfc=0.9
Sa=P_to_S(Pa,pfa)
Sb=P_to_S(Pb,pfb)
Sc=P_to_S(Pc,pfc)
S3=np.array([Sa,Sb,Sc])
bus2.loadS=0
bus3.loadS=0
bus4.loadS=S3
#bus4=Bus3(busa,busa,busa)
bus123=[bus1,bus2,bus3,bus4]
gen1=Generator3(bus1)
# line data
branch1=Line3(bus1,bus2,Z1)
branch2=Line3(bus2,bus3,Z2)
branch3=Line3(bus3,bus4,Z2)
#transformer data
t_connection='Step-Down'
t_MVA=6.0
t_kVLL_high=12.47
t_zbase= t_kVLL_high**2/t_MVA
t_kVLL_low=4.16
t_R=1.0/t_zbase
t_X=6.0/t_zbase
t_y=t_R + 1j* t_X
branch4=Trafo3(bus2,bus3,yt=t_y,base_mva=t_MVA)
branch12=[branch1,branch4,branch3]
kasus=Case3(base_mva=MVAbase, base_kva=kVAbase, buses=bus123, branches=branch12,generators=[gen1])

## ............................... Test ................................
T=Traverser(kasus)
FeederList=T.determineFeeder()
# test 
# print branch1.I_line
bs=bfs_pf(kasus)
bs.solve()
print np.abs(bs.presentE)

# print branch1.I_line
#bs.updateVoltage()
# print branch1.I_line
